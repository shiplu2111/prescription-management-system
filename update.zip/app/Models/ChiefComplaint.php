<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ChiefComplaint extends Model
{
    protected $fillable = [
        'name',
        'description',
    ];
}
