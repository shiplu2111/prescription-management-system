<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\Filament\AdminPanelProvider::class,
    App\Providers\Filament\DoctorPanelProvider::class,
    App\Providers\Filament\OwnerPanelProvider::class,
    App\Providers\Filament\PatientPanelProvider::class,
];
